#!/bin/bash
npx vercel --prod
